getwd()
setwd('D:\\DataMining\\程序')
data_alga = read.table('D:/DataMining/Analysis.txt',
                       col.names=c('season','size','speed','mxPH','mnO2','Cl','NO3','NH4','oPO4','PO4','Chla',
                                   'a1','a2','a3','a4','a5','a6','a7'),
                       na.string=c('XXXXXXX'))
####################  描述性分析  ###############################################################
#data<-data_alga[complete.cases(data_alga),]
data2<-data.frame(data_alga$mxPH,data_alga$mnO2,data_alga$Cl,data_alga$NO3,data_alga$NH4,data_alga$oPO4,data_alga$PO4,data_alga$Chla,data_alga$a1,data_alga$a2,data_alga$a3,data_alga$a4,data_alga$a5,data_alga$a6,data_alga$a7)
MU=sapply(data1,mean)
summary(data2)
sum(is.na(data_alga))
table(data_alga$season)
table(data_alga$size)
table(data_alga$speed)
write.csv(summary(data2),file="sumalga.csv")
#write.csv(result,'变量描述分析.csv',row.names=T)

#############################  可视化#######################################
#绘制直方图并正态性检验 
library(car)
library(lattice)

par(mfrow=c(1,2))
hist(data_alga$mxPH[!is.na(data_alga$mxPH)],xlab='mxPH',main='Histogram of mxpH value')
qqnorm(data_alga$mxPH[!is.na(data_alga$mxPH)],xlab='mxPH',main='qqnorm of  mxPH')
qqline(data_alga$mxPH[!is.na(data_alga$mxPH)],col='red')
boxplot(data_alga$mxPH[!is.na(data_alga$mxPH)],ylab='mxPH',main='mxpH 盒图')
rug(data_alga$mxPH[!is.na(data_alga$mxPH)],side=4)
abline(h=mean(data_alga$mxPH[!is.na(data_alga$mxPH)],na.rm=T),lty=2)

par(mfrow=c(1,2))
hist(data_alga$mnO2[!is.na(data_alga$mnO2)],xlab='mnO2',main='Histogram of mnO2')
qqnorm(data_alga$mnO2[!is.na(data_alga$mnO2)],xlab='mnO2',main='Norm QQ Plot of mnO2')
qqline(data_alga$mnO2[!is.na(data_alga$mnO2)],col='red')
boxplot(data_alga$mnO2[!is.na(data_alga$mnO2)],ylab='mnO2',main= 'mnO2 盒图')
rug(data_alga$mnO2[!is.na(data_alga$mnO2)],side=4)
abline(h=mean(data_alga$mnO2[!is.na(data_alga$mnO2)],na.rm=T),lty=2)

par(mfrow=c(1,2))
hist(data_alga$Cl[!is.na(data_alga$Cl)],xlab='Cl',main='Histogram of Cl value')
qqnorm(data_alga$Cl[!is.na(data_alga$Cl)],xlab='Cl',main='Norm QQ Plot of Cl')
qqline(data_alga$Cl[!is.na(data_alga$Cl)],col='red')
boxplot(data_alga$Cl[!is.na(data_alga$Cl)],ylab='Cl',xlab='Cl盒图')
rug(data_alga$Cl[!is.na(data_alga$Cl)],side=4)
abline(h=mean(data_alga$Cl[!is.na(data_alga$Cl)],na.rm=T),lty=2)

par(mfrow=c(1,2))
hist(data_alga$NO3[!is.na(data_alga$NO3)],xlab='NO3',main='Histogram of NO3 value')
qqnorm(data_alga$NO3[!is.na(data_alga$NO3)],xlab='NO3',main='Norm QQ Plot of NO3')
qqline(data_alga$NO3[!is.na(data_alga$NO3)],col='red')
boxplot(data_alga$NO3[!is.na(data_alga$NO3)],ylab='NO3',xlab='NO3')
rug(data_alga$Cl[!is.na(data_alga$NO3)],side=4)
abline(h=mean(data_alga$NO3[!is.na(data_alga$NO3)],na.rm=T),lty=2)

par(mfrow=c(1,2))
hist(data_alga$NH4[!is.na(data_alga$NH4)],xlab='NH4',main='Histogram of NH4 value')
qqnorm(data_alga$NH4[!is.na(data_alga$NH4)],xlab='NH4',main='Norm QQ Plot of NH4')
qqline(data_alga$NH4[!is.na(data_alga$NH4)],col='red')
boxplot(data_alga$NH4[!is.na(data_alga$NH4)],ylab='NH4',xlab='NH4盒图')
rug(data_alga$NH4[!is.na(data_alga$NH4)],side=4)
abline(h=mean(data_alga$NH4[!is.na(data_alga$NH4)],na.rm=T),lty=2)

par(mfrow=c(1,2))
hist(data_alga$oPO4[!is.na(data_alga$oPO4)],xlab='oPO4',main='Histogram ofoPO4 value')
qqnorm(data_alga$oPO4[!is.na(data_alga$oPO4)],xlab='oPO4',main='Norm QQ Plot of oPO4')
qqline(data_alga$oPO4[!is.na(data_alga$oPO4)],col='red')
boxplot(data_alga$oPO4[!is.na(data_alga$oPO4)],ylab='oPO4',xlab='NH4')
rug(data_alga$oPO4[!is.na(data_alga$oPO4)],side=4)
abline(h=mean(data_alga$oPO4[!is.na(data_alga$oPO4)],na.rm=T),lty=2)

par(mfrow=c(1,2))
hist(data_alga$PO4[!is.na(data_alga$PO4)],xlab='PO4',main='Histogram of PO4 value')
qqnorm(data_alga$PO4[!is.na(data_alga$PO4)],xlab='PO4',main='Norm QQ Plot of PO4')
qqline(data_alga$PO4[!is.na(data_alga$PO4)],col='red')
boxplot(data_alga$PO4[!is.na(data_alga$PO4)],ylab='PO4',xlab='PO4')
rug(data_alga$PO4[!is.na(data_alga$PO4)],side=4)
abline(h=mean(data_alga$PO4[!is.na(data_alga$PO4)],na.rm=T),lty=2)

par(mfrow=c(1,2))
hist(data_alga$Chla[!is.na(data_alga$Chla)],xlab='Chla',main='Histogram of Chla value')
qqnorm(data_alga$Chla[!is.na(data_alga$Chla)],xlab='Chla',main='Norm QQ Plot of Chla')
qqline(data_alga$PO4[!is.na(data_alga$PO4)],col='red')
qqline(data_alga$Chla[!is.na(data_alga$Chla)],col='red')
boxplot(data_alga$Chla[!is.na(data_alga$Chla)],ylab='Chla',xlab='Chla')
rug(data_alga$Chla[!is.na(data_alga$Chla)],side=4)
abline(h=mean(data_alga$Chla[!is.na(data_alga$Chla)],na.rm=T),lty=2)
###############################  绘制条件盒图  ########################################################
library(lattice)
par(mfrow=c(1,2))
bwplot(size~a1,data=data_alga,ylab='River Size',xlab='a1')
bwplot(size~a2,data=data_alga,ylab='River Size',xlab='a2')
bwplot(size~a3,data=data_alga,ylab='River Size',xlab='a3')
bwplot(size~a4,data=data_alga,ylab='River Size',xlab='a4')
bwplot(size~a5,data=data_alga,ylab='River Size',xlab='a5')
bwplot(size~a6,data=data_alga,ylab='River Size',xlab='a6')
bwplot(size~a7,data=data_alga,ylab='River Size',xlab='a7')
###############################  缺失值处理  ############################################
#删除缺失值
omitdata= na.omit(data_alga)
write.table(omitdata,"omitdata")
sum(is.na(omitdata))
#最高频数值替换

attach(data_alga)
data_alga$mxPH[is.na(data_alga$mxPH)]=max(table(data_alga$mxPH))
data_alga$mnO2[is.na(data_alga$mnO2)]=max(table(data_alga$mnO2))
data_alga$Cl[is.na(data_alga$Cl)]=max(table(data_alga$Cl))
data_alga$NO3[is.na(data_alga$NO3)]=max(table(data_alga$NO3))
data_alga$NH4[is.na(data_alga$NH4)]=max(table(data_alga$NH4))
data_alga$oPO4[is.na(data_alga$oPO4)]=max(table(data_alga$oPO4))
data_alga$PO4[is.na(data_alga$PO4)]=max(table(data_alga$PO4))
data_alga$Chla[is.na(data_alga$Chla)]=max(table(data_alga$Chla))
Chla<-data_alga$Chla[is.na(data_alga$Chla)]
C1<-data_alga$Cl[is.na(data_alga$Cl)]
maPH<-data_alga$mxPH[is.na(data_alga$mxPH)]

data_maxfre<-data_alga
par(mfrow=c(1,2))
data_maxfre[,4:11]<-data.frame(data_alga$mxPH,data_alga$mnO2,data_alga$Cl,data_alga$NO3,data_alga$NH4,data_alga$oPO4,data_alga$PO4,data_alga$Chla)
boxplot(data_maxfre[,4],main='maxre mxpH')
boxplot(data_alga[,4],main='mxpH ')
boxplot(data_maxfre[,6],main='maxre C1')
boxplot(data_alga[,6],main='c1 ')
boxplot(data_maxfre[,11],main='maxre Chla1')
boxplot(data_alga[,11],main='Chla ')
write.table(data_maxfre,"maxfre replace")
sum(is.na(data_maxfre))
#相关系数替换
